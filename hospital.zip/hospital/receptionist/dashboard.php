<?php
require_once '../config/database.php';

if (!isLoggedIn() || !hasRole('receptionist')) {
    redirect('../login.php');
}

// Get statistics
$stats = [];

// Total patients
$result = $conn->query("SELECT COUNT(*) as count FROM patients");
$stats['patients'] = $result->fetch_assoc()['count'];

// Today's appointments
$result = $conn->query("SELECT COUNT(*) as count FROM appointments WHERE appointment_date = CURDATE()");
$stats['today_appointments'] = $result->fetch_assoc()['count'];

// Pending bills
$result = $conn->query("SELECT COUNT(*) as count FROM billing WHERE payment_status = 'pending'");
$stats['pending_bills'] = $result->fetch_assoc()['count'];

// Total appointments
$result = $conn->query("SELECT COUNT(*) as count FROM appointments");
$stats['total_appointments'] = $result->fetch_assoc()['count'];

// Recent patients
$recent_patients = $conn->query("
    SELECT * FROM patients 
    ORDER BY registration_date DESC 
    LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receptionist Dashboard - HMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <?php include '../includes/sidebar.php'; ?>
        <div class="main-content">
            <?php include '../includes/topbar.php'; ?>
            
            <div class="page-header">
                <h1>Receptionist Dashboard</h1>
            </div>

            <div class="card-grid">
                <div class="card">
                    <div class="icon">🧑‍🤝‍🧑</div>
                    <div class="number"><?php echo $stats['patients']; ?></div>
                    <div class="label">Total Patients</div>
                </div>
                <div class="card">
                    <div class="icon">📅</div>
                    <div class="number"><?php echo $stats['today_appointments']; ?></div>
                    <div class="label">Today's Appointments</div>
                </div>
                <div class="card">
                    <div class="icon">💰</div>
                    <div class="number"><?php echo $stats['pending_bills']; ?></div>
                    <div class="label">Pending Bills</div>
                </div>
                <div class="card">
                    <div class="icon">📋</div>
                    <div class="number"><?php echo $stats['total_appointments']; ?></div>
                    <div class="label">Total Appointments</div>
                </div>
            </div>

            <div class="table-container">
                <h3>Recent Patient Registrations</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>DOB</th>
                            <th>Gender</th>
                            <th>Phone</th>
                            <th>Registered</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recent_patients && $recent_patients->num_rows > 0): ?>
                            <?php while ($row = $recent_patients->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                                    <td><?php echo date('d M Y', strtotime($row['date_of_birth'])); ?></td>
                                    <td><?php echo htmlspecialchars($row['gender']); ?></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td><?php echo date('d M Y', strtotime($row['registration_date'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">No patients registered yet</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>