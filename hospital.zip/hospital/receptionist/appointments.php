<?php
require_once '../config/database.php';

if (!isLoggedIn() || !hasRole('receptionist')) {
    redirect('../login.php');
}

$success = '';
$error = '';

// Get patients and doctors for dropdown
$patients = $conn->query("SELECT id, first_name, last_name FROM patients ORDER BY first_name");
$doctors = $conn->query("
    SELECT d.*, u.full_name 
    FROM doctors d 
    JOIN users u ON d.user_id = u.id
");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = "Invalid security token. Please try again.";
    } else {
        $patient_id = intval($_POST['patient_id']);
        $doctor_id = intval($_POST['doctor_id']);
        $date = sanitize($_POST['date']);
        $time = sanitize($_POST['time']);
        $notes = sanitize($_POST['notes']);

        // Validate
        if ($patient_id <= 0 || $doctor_id <= 0 || empty($date) || empty($time)) {
            $error = "Please fill in all required fields.";
        } else {
            $sql = "INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, notes) 
                    VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iisss", $patient_id, $doctor_id, $date, $time, $notes);
            
            if ($stmt->execute()) {
                $success = "Appointment booked successfully!";
            } else {
                $error = "Failed to book appointment. Please try again.";
            }
            $stmt->close();
        }
    }
}

// Get today's appointments
$today_appointments = $conn->query("
    SELECT a.*, 
           p.first_name as patient_first, p.last_name as patient_last,
           u.full_name as doctor_name
    FROM appointments a 
    JOIN patients p ON a.patient_id = p.id 
    JOIN doctors d ON a.doctor_id = d.id 
    JOIN users u ON d.user_id = u.id 
    WHERE a.appointment_date = CURDATE()
    ORDER BY a.appointment_time
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment - HMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <?php include '../includes/sidebar.php'; ?>
        <div class="main-content">
            <?php include '../includes/topbar.php'; ?>
            
            <div class="page-header">
                <h1>Book Appointment</h1>
                <a href="../admin/manage_appointments.php" class="btn-secondary" style="text-decoration:none;">← Back to Appointments</a>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST" style="background:white; padding:25px; border-radius:10px; margin-bottom:30px;">
                <?php echo csrf_field(); ?>
                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px;">
                    <div class="form-group">
                        <label>Patient *</label>
                        <select name="patient_id" required>
                            <option value="">Select Patient</option>
                            <?php while ($row = $patients->fetch_assoc()): ?>
                                <option value="<?php echo $row['id']; ?>">
                                    <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                        <small style="color:#95a5a6;">Don't see the patient? <a href="register_patient.php" style="color:#667eea;">Register here</a></small>
                    </div>
                    <div class="form-group">
                        <label>Doctor *</label>
                        <select name="doctor_id" required>
                            <option value="">Select Doctor</option>
                            <?php while ($row = $doctors->fetch_assoc()): ?>
                                <option value="<?php echo $row['id']; ?>">
                                    <?php echo htmlspecialchars($row['full_name'] . ' (' . $row['specialization'] . ')'); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Date *</label>
                        <input type="date" name="date" required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="form-group">
                        <label>Time *</label>
                        <input type="time" name="time" required>
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Notes</label>
                        <textarea name="notes" rows="2" placeholder="Any special notes for this appointment"></textarea>
                    </div>
                </div>
                <div style="margin-top:20px; display:flex; gap:10px;">
                    <button type="submit" class="btn-primary">Book Appointment</button>
                    <a href="../admin/manage_appointments.php" class="btn-secondary" style="text-decoration:none;padding:10px 20px;">Cancel</a>
                </div>
            </form>

            <h2>Today's Appointments</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Patient</th>
                            <th>Doctor</th>
                            <th>Time</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($today_appointments && $today_appointments->num_rows > 0): ?>
                            <?php while ($row = $today_appointments->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['patient_first'] . ' ' . $row['patient_last']); ?></td>
                                    <td><?php echo htmlspecialchars($row['doctor_name']); ?></td>
                                    <td><?php echo date('h:i A', strtotime($row['appointment_time'])); ?></td>
                                    <td><span class="status status-<?php echo htmlspecialchars($row['status']); ?>"><?php echo ucfirst(htmlspecialchars($row['status'])); ?></span></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">No appointments today</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>