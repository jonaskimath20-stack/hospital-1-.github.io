<?php
require_once '../config/database.php';

if (!isLoggedIn() || !hasRole('doctor')) {
    redirect('../login.php');
}

$user_id = $_SESSION['user_id'];

// Get doctor info with prepared statement
$stmt = $conn->prepare("
    SELECT d.*, u.full_name, u.email, u.phone 
    FROM doctors d 
    JOIN users u ON d.user_id = u.id 
    WHERE d.user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$doctor = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$doctor) {
    redirect('../login.php');
}

$doctor_id = $doctor['id'];

// Get today's appointments
$today_appointments = $conn->query("
    SELECT a.*, p.first_name, p.last_name, p.phone, p.medical_history
    FROM appointments a 
    JOIN patients p ON a.patient_id = p.id 
    WHERE a.doctor_id = $doctor_id AND a.appointment_date = CURDATE()
    ORDER BY a.appointment_time
");

// Get total patients for this doctor
$total_patients = $conn->query("
    SELECT COUNT(DISTINCT patient_id) as count 
    FROM appointments 
    WHERE doctor_id = $doctor_id
")->fetch_assoc()['count'];

// Get appointment counts by status
$status_counts = [];
$statuses = ['scheduled', 'completed', 'cancelled', 'no-show'];
foreach ($statuses as $status) {
    $result = $conn->query("
        SELECT COUNT(*) as count FROM appointments 
        WHERE doctor_id = $doctor_id AND status = '$status'
    ");
    $status_counts[$status] = $result->fetch_assoc()['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard - HMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <?php include '../includes/sidebar.php'; ?>
        <div class="main-content">
            <?php include '../includes/topbar.php'; ?>
            
            <div class="page-header">
                <h1>Doctor Dashboard</h1>
                <p>Welcome, Dr. <?php echo htmlspecialchars($doctor['full_name']); ?></p>
            </div>

            <div class="card-grid">
                <div class="card">
                    <div class="icon">📅</div>
                    <div class="number"><?php echo $today_appointments->num_rows; ?></div>
                    <div class="label">Today's Appointments</div>
                </div>
                <div class="card">
                    <div class="icon">🧑‍🤝‍🧑</div>
                    <div class="number"><?php echo $total_patients; ?></div>
                    <div class="label">Total Patients</div>
                </div>
                <div class="card">
                    <div class="icon">📋</div>
                    <div class="number"><?php echo $status_counts['scheduled']; ?></div>
                    <div class="label">Scheduled</div>
                </div>
                <div class="card">
                    <div class="icon">✅</div>
                    <div class="number"><?php echo $status_counts['completed']; ?></div>
                    <div class="label">Completed</div>
                </div>
            </div>

            <div class="table-container">
                <h3>Today's Appointments</h3>
                <?php if ($today_appointments && $today_appointments->num_rows > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Patient</th>
                                <th>Time</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $today_appointments->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                                    <td><?php echo date('h:i A', strtotime($row['appointment_time'])); ?></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td><span class="status status-<?php echo htmlspecialchars($row['status']); ?>"><?php echo ucfirst(htmlspecialchars($row['status'])); ?></span></td>
                                    <td>
                                        <a href="view_patient.php?id=<?php echo $row['patient_id']; ?>" class="btn-primary" style="padding:4px 10px;font-size:12px;text-decoration:none;">View</a>
                                        <a href="update_status.php?appointment=<?php echo $row['id']; ?>&status=completed" class="btn-success" style="padding:4px 10px;font-size:12px;text-decoration:none;" onclick="return confirm('Mark this appointment as completed?')">Complete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-center">No appointments scheduled for today.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>