<?php
require_once '../config/database.php';

if (!isLoggedIn() || !hasRole('doctor')) {
    redirect('../login.php');
}

$patient_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($patient_id <= 0) {
    redirect('dashboard.php');
}

// Get patient details
$patient = $conn->query("
    SELECT * FROM patients WHERE id = $patient_id
")->fetch_assoc();

if (!$patient) {
    redirect('dashboard.php');
}

// Get patient's appointments
$appointments = $conn->query("
    SELECT a.*, u.full_name as doctor_name, d.specialization
    FROM appointments a 
    JOIN doctors d ON a.doctor_id = d.id 
    JOIN users u ON d.user_id = u.id 
    WHERE a.patient_id = $patient_id 
    ORDER BY a.appointment_date DESC
");

// Get patient's bills
$bills = $conn->query("
    SELECT * FROM billing 
    WHERE patient_id = $patient_id 
    ORDER BY created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Details - HMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="dashboard">
        <?php include '../includes/sidebar.php'; ?>
        <div class="main-content">
            <?php include '../includes/topbar.php'; ?>
            
            <div class="page-header">
                <h1>Patient Details</h1>
                <a href="dashboard.php" class="btn-secondary" style="text-decoration:none;">← Back to Dashboard</a>
            </div>

            <!-- Patient Information -->
            <div style="background:white; padding:20px; border-radius:10px; margin-bottom:20px;">
                <h3>Personal Information</h3>
                <div style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap:15px; margin-top:15px;">
                    <div><strong>Full Name:</strong> <?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></div>
                    <div><strong>Date of Birth:</strong> <?php echo date('d M Y', strtotime($patient['date_of_birth'])); ?></div>
                    <div><strong>Gender:</strong> <?php echo htmlspecialchars($patient['gender']); ?></div>
                    <div><strong>Phone:</strong> <?php echo htmlspecialchars($patient['phone'] ?? 'N/A'); ?></div>
                    <div><strong>Email:</strong> <?php echo htmlspecialchars($patient['email'] ?? 'N/A'); ?></div>
                    <div><strong>Emergency Contact:</strong> <?php echo htmlspecialchars($patient['emergency_contact'] ?? 'N/A'); ?></div>
                </div>
                <div style="margin-top:15px;">
                    <strong>Address:</strong> <?php echo htmlspecialchars($patient['address'] ?? 'N/A'); ?>
                </div>
                <div style="margin-top:15px;">
                    <strong>Medical History:</strong>
                    <p style="background:#f8f9fa; padding:10px; border-radius:5px; margin-top:5px;">
                        <?php echo htmlspecialchars($patient['medical_history'] ?? 'No medical history recorded.'); ?>
                    </p>
                </div>
            </div>

            <!-- Appointment History -->
            <div class="table-container" style="margin-bottom:20px;">
                <h3>Appointment History</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Doctor</th>
                            <th>Specialization</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($appointments && $appointments->num_rows > 0): ?>
                            <?php while ($row = $appointments->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo date('d M Y', strtotime($row['appointment_date'])); ?></td>
                                    <td><?php echo date('h:i A', strtotime($row['appointment_time'])); ?></td>
                                    <td><?php echo htmlspecialchars($row['doctor_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['specialization']); ?></td>
                                    <td><span class="status status-<?php echo htmlspecialchars($row['status']); ?>"><?php echo ucfirst(htmlspecialchars($row['status'])); ?></span></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">No appointments found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Billing History -->
            <div class="table-container">
                <h3>Billing History</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($bills && $bills->num_rows > 0): ?>
                            <?php while ($row = $bills->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo date('d M Y', strtotime($row['created_at'])); ?></td>
                                    <td>$<?php echo number_format($row['amount'], 2); ?></td>
                                    <td><?php echo ucfirst(htmlspecialchars($row['payment_method'])); ?></td>
                                    <td><span class="status status-<?php echo htmlspecialchars($row['payment_status']); ?>"><?php echo ucfirst(htmlspecialchars($row['payment_status'])); ?></span></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">No bills found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>